import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

export default function ListaLocal() {
  return (
    <View>
      <Text>ListaLocal</Text>
    </View>
  )
}

const styles = StyleSheet.create({})